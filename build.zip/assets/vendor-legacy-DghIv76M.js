System.register(["./vkui-legacy-CZc4SvEZ.js"],(function(e,t){"use strict";return{setters:[null],execute:function(){}}}));
